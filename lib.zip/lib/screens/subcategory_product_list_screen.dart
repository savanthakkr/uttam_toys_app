import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:uttam_toys/apis/api_manager.dart';
import 'package:uttam_toys/models/all_product_model.dart';
import 'package:uttam_toys/screens/product_details_screen.dart';
import 'package:uttam_toys/utils/assets.dart';
import 'package:uttam_toys/utils/connection_utils.dart';
import 'package:uttam_toys/utils/custom_color.dart';
import 'package:uttam_toys/utils/custom_style.dart';
import 'package:uttam_toys/utils/dimensions.dart';
import 'package:uttam_toys/utils/intentutils.dart';
import 'package:uttam_toys/utils/size.dart';
import 'package:uttam_toys/utils/ui_utils.dart';
import 'package:uttam_toys/widgets/appbar_common.dart';

class SubcategoryProductListScreen extends StatefulWidget {

  String subCat;

  SubcategoryProductListScreen({super.key,required this.subCat});

  @override
  State<SubcategoryProductListScreen> createState() => _SubcategoryProductListScreenState();
}

class _SubcategoryProductListScreenState extends State<SubcategoryProductListScreen> {

  List<AllProduct> productList = <AllProduct>[];
  bool _isLoading = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getProducts();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) {
        if (didPop) {
          return;
        }
        if (context.mounted) {
          _onBackPressed();
        }
      },
      child: Scaffold(
        backgroundColor: CustomColor.backgroundColor,
        appBar: CommonAppbar(
          title: widget.subCat,
          leadingOnTap: _onBackPressed,
        ),
        body:  _isLoading ? Center(child: CircularProgressIndicator(color: CustomColor.primaryColor,)) : GridView.builder(
            padding: EdgeInsets.symmetric(horizontal: Dimensions.widthSize*1.5,vertical: Dimensions.heightSize),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: MediaQuery.of(context).size.width /
                    (MediaQuery.of(context).size.height / 1.35),
                crossAxisSpacing: 10,
                mainAxisSpacing: 10),
            itemCount: productList.length,
            itemBuilder: (BuildContext ctx, index) {
              return _itemView(productList[index]);
            }),
      ),
    );
  }

  _itemView(AllProduct toy) {

    dynamic bytes;
    if(toy.images.isNotEmpty){
      if(toy.images.first.isNotEmpty) {
        bytes = base64.decode(toy.images.first);
      } else {
        bytes = null;
      }
    } else {
      bytes = null;
    }

    return GestureDetector(
      onTap: (){
        IntentUtils.fireIntent(context: context, screen: ProductDetailsScreen(pId: toy.id.toString(),), finishAll: false);
      },
      child: Card(
        elevation: 0,
        color: CustomColor.whiteColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Dimensions.radius),
            side: const BorderSide(color: CustomColor.borderColor,width: 1,style: BorderStyle.solid)
        ),
        clipBehavior: Clip.antiAlias,
        child: ConstrainedBox(
          constraints: BoxConstraints(
              minWidth: 120,
              minHeight: 120,
              maxWidth: 140
          ),
          child: Column(
            crossAxisAlignment: crossStretch,
            children: [
              Container(
                color: CustomColor.cardColor,
                height: 120,
                width: double.infinity,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    bytes != null ? Image.memory(bytes,height: 100,) : Image.asset(Assets.shapes,height: 100,),
                    Positioned(
                      right: 5,
                      top: 10,
                      child: InkWell(
                        onTap: () {
                          //todo add/remove wishlist
                        },
                        child: Icon(
                          toy.isWishlisted == null || !toy.isWishlisted! ? Icons.favorite_border_rounded : Icons.favorite,
                          color: CustomColor.primaryColor,
                          size: Dimensions.iconSizeDefault,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              addVerticalSpace(Dimensions.heightSize*0.2),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: Dimensions.widthSize,
                    vertical: 0
                ),
                child: Row(
                  crossAxisAlignment: crossStart,
                  children: [
                    Flexible(
                      child: Text(toy.name ?? '',
                        textAlign: TextAlign.start,
                        style: CustomStyle.smallHeadingTextStyle,),
                    ),
                    const Spacer(),
                    Row(
                      mainAxisSize: mainMin,
                      mainAxisAlignment: mainSpaceBet,
                      children: [
                        SvgPicture.asset(Assets.starSvg,height: 12,width: 12,),
                        Text("4.5" ?? '',
                          style: CustomStyle.blackSmallestTextStyle,
                          textAlign: TextAlign.end,),
                      ],
                    )
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: mainMin,
                children: [
                  Text('\u20b9 ${toy.discountPrice}',
                    style: CustomStyle.blackSmallestTextStyle,
                    textAlign: TextAlign.start,),
                  addHorizontalSpace(Dimensions.widthSize*0.5),
                  Text('\u20b9 ${toy.mainPrice}',
                    style: CustomStyle.cancelledTextStyle,
                    textAlign: TextAlign.start,),
                ],
              ).paddingSymmetric(
                  horizontal: Dimensions.widthSize,
                  vertical: 0
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: Dimensions.widthSize,
                    vertical: Dimensions.heightSize*0.1
                ),
                child: toy.priceDrop!=null ? Row(
                  mainAxisSize: mainMin,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(Icons.info_outline_rounded,color: CustomColor.borderColor,size: Dimensions.iconSizeSmall,),
                    addHorizontalSpace(Dimensions.widthSize*0.2),
                    Text('Price dropped by \u20b9${toy.priceDrop}',
                      style: CustomStyle.blackSmallestTextStyle.copyWith(
                          fontSize: 10
                      ),
                      textAlign: TextAlign.start,),
                  ],
                )  : SizedBox(height: Dimensions.heightSize,),
              ),
              const Divider(
                color: CustomColor.borderColor,
                height: 0,
                thickness: 0.5,
              ),
              InkWell(
                onTap: () {
                  //todo add cart
                },
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: Dimensions.heightSize*0.5,
                      horizontal: 0
                  ),
                  child: Center(
                    child: Text(
                      'move to bag'.toUpperCase(),
                      textAlign: TextAlign.center,
                      style: CustomStyle.primaryRegularBoldText,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void getProducts() {
    ConnectionUtils.checkConnection().then((intenet) async {
      if (intenet) {
        setState(() {
          _isLoading = true;
          productList.clear();
        });
        try{
          final AllProductModel resultModel = await ApiManager.FetchSubCategoryByProduct(widget.subCat);

          if(resultModel.error == false) {
            setState(() {
              _isLoading = false;
              productList = resultModel.allProducts;
            });

          } else{
            setState(() {
              _isLoading = false;
            });
            UIUtils.bottomToast(context: context, text: resultModel.message, isError: true);
          }
        }
        on Exception catch(_,e){
          setState(() {
            _isLoading = false;
          });
          print(e.toString());
          UIUtils.bottomToast(context: context, text: e.toString(), isError: true);
        }
      }
      else {
        // No-Internet Case
        UIUtils.bottomToast(context: context, text: "Please check your internet connection", isError: true);
      }
    });
  }

  void _onBackPressed() {
    Navigator.of(context).pop();
    // return false;
  }
}

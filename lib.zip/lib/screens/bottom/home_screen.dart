import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:uttam_toys_app/models/toys_model.dart';
import 'package:uttam_toys_app/screens/category_list_screen.dart';
import 'package:uttam_toys_app/screens/notifications_screen.dart';
import 'package:uttam_toys_app/screens/product_details_screen.dart';
import 'package:uttam_toys_app/screens/product_list_screen.dart';
import 'package:uttam_toys_app/utils/assets.dart';
import 'package:uttam_toys_app/utils/custom_color.dart';
import 'package:uttam_toys_app/utils/custom_style.dart';
import 'package:uttam_toys_app/utils/dimensions.dart';
import 'package:uttam_toys_app/utils/intentutils.dart';
import 'package:uttam_toys_app/utils/size.dart';

import '../../models/category_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _bannerList = [
    'assets/temp/banner.png',
    'assets/temp/banner.png',
    'assets/temp/banner.png'
  ];

  final catList = <CategoryModel>[
    CategoryModel('Blocks',Assets.bricks),
    CategoryModel('Puzzle',Assets.puzzle),
    CategoryModel('Educational',Assets.education),
    CategoryModel('Outdoor',Assets.outdoor),
    CategoryModel('Dolls',Assets.dolls),
  ];

  final toysList = <ToysModel>[
    ToysModel('Colorful shape', Assets.shapes, '499', '4.5', false),
    ToysModel('Colorful shape', Assets.shapes, '499', '4.5', false),
    ToysModel('Colorful shape', Assets.shapes, '499', '4.5', true),
    ToysModel('Colorful shape', Assets.shapes, '499', '4.5', false),
    ToysModel('Colorful shape', Assets.shapes, '499', '4.5', false),
  ];
  late double mWidth,mHeight;

  @override
  Widget build(BuildContext context) {
    mWidth = MediaQuery.of(context).size.width;
    mHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: CustomColor.backgroundColor,
      appBar: AppBar(
        backgroundColor: CustomColor.whiteColor,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(greeting(),style: CustomStyle.blackMediumTextStyle.copyWith(
              fontSize: Dimensions.regularTextSize
            ),),
            Text('User',style: CustomStyle.regularBlackLightText.copyWith(
                fontSize: Dimensions.smallestTextSize
            ),)
          ],
        ),
        actions: [
          InkWell(
            onTap: () {
              //todo
            },
            child: SvgPicture.asset(
              Assets.searchSvg,
              height: 20,
              width: 20,
            ),
          ),
          addHorizontalSpace(Dimensions.widthSize),
          InkWell(
            onTap: () {
              IntentUtils.fireIntent(context: context, screen: NotificationsScreen(), finishAll: false);
            },
            child: SvgPicture.asset(
              Assets.bellSvg,
              height: 20,
              width: 20,
            ),
          ),
          addHorizontalSpace(Dimensions.widthSize),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.symmetric(
          vertical: Dimensions.heightSize,
          horizontal: 0
        ),
        children: [
          CarouselSlider(
            options: CarouselOptions(
                autoPlay: true,
                autoPlayInterval: const Duration(seconds: 3),
                height: mHeight*0.24),
            items: _bannerList
                .map((item) =>
                Container(
                  child: bannerItems(item),
                )
            )
                .toList(),
          ),
          addVerticalSpace(Dimensions.heightSize),
          _headingText(title: 'Categories', onTap: () {
            IntentUtils.fireIntent(context: context, screen: CategoryListScreen(type: 'All',), finishAll: false);
          },),
          _categoryList(),
          addVerticalSpace(Dimensions.heightSize),
          _headingText(title: 'Trending Products', onTap: () {
            IntentUtils.fireIntent(context: context, screen: ProductListScreen(type: 'Trending Products'),
                finishAll: false);
          },),
          _trendingList(),
          addVerticalSpace(Dimensions.heightSize),
          _headingText(title: 'Featured Products', onTap: () {
            IntentUtils.fireIntent(context: context, screen: ProductListScreen(type: 'Featured Products'),
                finishAll: false);
          },),
          _trendingList(),
          addVerticalSpace(Dimensions.heightSize),
          _headingText(title: 'Best Selling Products', onTap: () {
            IntentUtils.fireIntent(context: context, screen: ProductListScreen(type: 'Best Selling Products'),
                finishAll: false);
          },),
          _trendingList()
        ],
      ),
    );
  }

  String greeting() {
    var hour = DateTime.now().hour;
    if (hour < 12) {
      return 'Good Morning';
    }
    if (hour < 17) {
      return 'Good Afternoon';
    }
    return 'Good Evening';
  }

  Widget bannerItems(String? item) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: Dimensions.widthSize * 0.2),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10.0),
        child: Image.asset(
          item!,
          width: double.infinity,
          height: mWidth,
          fit: BoxFit.fill,
        ),
      ),
    );
  }
  
  _headingText({required String title,required GestureTapCallback onTap})
  {
    return Row(
      mainAxisAlignment: mainSpaceBet,
      children: [
        Expanded(
          child: Text(title,
            style: CustomStyle.primaryRegularBoldText,
            textAlign: TextAlign.start,),
        ),
        Expanded(
          child: InkWell(
            onTap: onTap,
            child: Row(
              mainAxisSize: mainMax,
              mainAxisAlignment: mainEnd,
              children: [
                Text('View All',
                  style: CustomStyle.primaryRegularBoldText,
                  textAlign: TextAlign.end,),
                const Icon(
                  Icons.keyboard_arrow_right,
                  color: CustomColor.primaryColor,
                )
              ],
            ),
          ),
        ),
      ],
    ).paddingSymmetric(
        vertical: 0,
        horizontal: Dimensions.widthSize*0.5
    );
  }

  _categoryList() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      padding: EdgeInsets.symmetric(
          vertical: Dimensions.heightSize*0.5,
          horizontal: 0
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: mainSpaceBet,
        children: [
          for(int i=0; i<catList.length ; i++)
            _rowCats(catList.elementAt(i))
        ],
      ),
    );
  }

  _rowCats(CategoryModel category) {
    return Column(
      crossAxisAlignment: crossCenter,
      children: [
        SizedBox(
          height: 65,
          width: 65,
          child: Stack(
            children: [
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: CustomColor.primaryColor
                ),
              ),
              Image.asset(
                  category.image!,
                height: 65,
                width: 65,
              )
            ],
          ),
        ),
        Text(category.name ?? '',style: CustomStyle.smallHeadingTextStyle,textAlign: TextAlign.center,)
      ],
    ).marginOnly(left: Dimensions.widthSize*0.5,right: Dimensions.widthSize*0.5);
  }

  _trendingList() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      padding: EdgeInsets.symmetric(
          vertical: Dimensions.heightSize*0.5,
          horizontal: Dimensions.widthSize
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: mainSpaceBet,
        children: [
          for(int i=0; i<toysList.length ; i++)
            _rowToys(toysList.elementAt(i))
        ],
      ),
    );
  }

  _rowToys(ToysModel toy) {
    return Card(
      elevation: 0,
      color: CustomColor.cardColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(Dimensions.radius*1.8)
      ),
      child: InkWell(
        onTap: () {
          IntentUtils.fireIntent(context: context, screen: ProductDetailsScreen(), finishAll: false);
        },
        child: ConstrainedBox(
          constraints: const BoxConstraints(
            minWidth: 120,
            minHeight: 120,
            maxWidth: 140
          ),
          child: Column(
            crossAxisAlignment: crossStart,
            children: [
              SizedBox(
                height: 120,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Image.asset(toy.image!,height: 100,),
                    Positioned(
                      right: 2,
                      top: 10,
                      child: InkWell(
                        onTap: () {
                          //todo add/remove wishlist
                        },
                        child: Icon(
                          !toy.isWishlisted! ? Icons.favorite_border_rounded : Icons.favorite,
                          color: CustomColor.primaryColor,
                          size: Dimensions.iconSizeDefault,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              addVerticalSpace(Dimensions.heightSize*0.5),
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: Dimensions.widthSize,
                  vertical: 0
                ),
                child: Text(toy.name ?? '',
                  textAlign: TextAlign.start,
                  style: CustomStyle.smallHeadingTextStyle,),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: mainMax,
                children: [
                  Text('\u20b9 ${toy.price}',
                    style: CustomStyle.blackSmallestTextStyle,
                  textAlign: TextAlign.start,),
                  const Spacer(),
                  Row(
                    mainAxisSize: mainMax,
                    mainAxisAlignment: mainSpaceBet,
                    children: [
                      SvgPicture.asset(Assets.starSvg,height: 12,width: 12,),
                      Text(toy.rating ?? '',
                        style: CustomStyle.blackSmallestTextStyle,
                      textAlign: TextAlign.end,),
                    ],
                  )
                ],
              ).paddingSymmetric(
                  horizontal: Dimensions.widthSize,
                  vertical: Dimensions.heightSize*0.2
              )
            ],
          ),
        ),
      ),
    );
  }
}

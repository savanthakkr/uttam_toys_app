class WishlistModel{
  String? name;
  String? image;
  String? price;
  String? oldPrice;
  String? rating;
  bool? isWishlisted;
  String? priceDrop;

  WishlistModel(this.name, this.image, this.price,this.oldPrice, this.rating, this.isWishlisted,this.priceDrop);
}
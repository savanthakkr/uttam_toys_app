class CartModel{
  String? name;
  String? image;
  String? price;
  String? oldPrice;
  String? rating;
  bool? inStock;
  String? priceDrop;
  String? color;

  CartModel(this.name, this.image, this.price,this.oldPrice, this.rating, this.inStock,this.priceDrop,this.color);
}
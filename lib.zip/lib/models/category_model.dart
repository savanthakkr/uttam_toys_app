class CategoryModel{
  String? name;
  String? image;

  CategoryModel(this.name, this.image);
}
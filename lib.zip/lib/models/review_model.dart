class ReviewModel{
  String? name;
  String? rating;
  String? review;

  ReviewModel(this.name, this.rating,this.review);
}
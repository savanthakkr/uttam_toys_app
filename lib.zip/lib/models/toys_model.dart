class ToysModel{
  String? name;
  String? image;
  String? price;
  String? rating;
  bool? isWishlisted;

  ToysModel(this.name, this.image, this.price, this.rating, this.isWishlisted);
}
class OrderStatusModel{
  String? status;
  bool? isDone;

  OrderStatusModel(this.status, this.isDone);
}
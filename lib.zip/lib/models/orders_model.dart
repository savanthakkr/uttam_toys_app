class OrdersModel{
  String? name;
  String? image;
  String? date;
  String? status;

  OrdersModel(this.name, this.image, this.date, this.status);
}
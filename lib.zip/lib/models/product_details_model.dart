import 'dart:convert';

ProductDetailsModel productDetailsModelFromJson(String str) => ProductDetailsModel.fromJson(json.decode(str));

String productDetailsModelToJson(ProductDetailsModel data) => json.encode(data.toJson());

class ProductDetailsModel {
  bool error;
  String message;
  List<ProductDetail> productDetails;

  ProductDetailsModel({
    required this.error,
    required this.message,
    required this.productDetails,
  });

  factory ProductDetailsModel.fromJson(Map<String, dynamic> json) => ProductDetailsModel(
    error: json["error"],
    message: json["message"],
    productDetails: json["ProductDetails"] != null ? List<ProductDetail>.from(json["ProductDetails"].map((x) => ProductDetail.fromJson(x))) : [],
  );

  Map<String, dynamic> toJson() => {
    "error": error,
    "message": message,
    "ProductDetails": List<dynamic>.from(productDetails.map((x) => x.toJson())),
  };
}

class ProductDetail {
  int id;
  String name;
  String categoryId;
  String subCategoryId;
  String brandId;
  String descriptionShort;
  String descriptionLong;
  String mainPrice;
  String discountPrice;
  String quantity;
  String sku;
  String taxValue;
  String tags;
  String age;
  int status;
  DateTime createdAt;
  DateTime updatedAt;
  List<String> images;

  ProductDetail({
    required this.id,
    required this.name,
    required this.categoryId,
    required this.subCategoryId,
    required this.brandId,
    required this.descriptionShort,
    required this.descriptionLong,
    required this.mainPrice,
    required this.discountPrice,
    required this.quantity,
    required this.sku,
    required this.taxValue,
    required this.tags,
    required this.age,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.images,
  });

  factory ProductDetail.fromJson(Map<String, dynamic> json) => ProductDetail(
    id: json["id"],
    name: json["name"],
    categoryId: json["category_id"],
    subCategoryId: json["sub_category_id"],
    brandId: json["brand_id"],
    descriptionShort: json["description_short"],
    descriptionLong: json["description_long"],
    mainPrice: json["main_price"],
    discountPrice: json["discount_price"],
    quantity: json["quantity"],
    sku: json["sku"],
    taxValue: json["tax_value"],
    tags: json["tags"],
    age: json["age"],
    status: json["status"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    images: json["images"] != null ? List<String>.from(json["images"].map((x) => x)) : [],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "category_id": categoryId,
    "sub_category_id": subCategoryId,
    "brand_id": brandId,
    "description_short": descriptionShort,
    "description_long": descriptionLong,
    "main_price": mainPrice,
    "discount_price": discountPrice,
    "quantity": quantity,
    "sku": sku,
    "tax_value": taxValue,
    "tags": tags,
    "age": age,
    "status": status,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "images": List<dynamic>.from(images.map((x) => x)),
  };
}

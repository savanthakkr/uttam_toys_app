class Prefs{
  static String RPHONE = "rphone";
  static String FPHONE = "fphone";

  static String flag = 'userType';

  static String ID = "id";
  static String TOKEN = "token";
  static String NAME = "name";
  static String EMAIL = "email";
  static String PHONE = "phone";
  static String isLogin = "isLoggedIn";
  static String onBoardseen = "onboard";
  static String dialogLastShownAt = "location_dialog_shown_at";
}